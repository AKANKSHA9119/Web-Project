const express = require('express');
const bodyParser = require('body-parser');
const employeeRoutes = require('./routes/employeeRoutes');
const adminRoutes = require('./routes/adminRoutes');
const db = require('./models');

const app = express();
app.use(bodyParser.json());

app.use('/employee', employeeRoutes);
app.use('/admin', adminRoutes);

db.sequelize.sync().then(() => {
  console.log('Database synchronized successfully.');
}).catch((err) => {
  console.log('Error: ' + err);
});

module.exports = app;