const db = require('../models');
const Leave = db.Leave;

exports.getAllLeaves = async (req, res) => {
  try {
    const leaves = await Leave.findAll();
    res.status(200).json(leaves);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.updateLeaveStatus = async (req, res) => {
  try {
    const { status } = req.body;
    const leave = await Leave.findByPk(req.params.leaveId);
    leave.status = status;
    await leave.save();
    res.status(200).json(leave);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};