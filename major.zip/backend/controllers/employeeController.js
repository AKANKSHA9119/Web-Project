const db = require('../models');
const Leave = db.Leave;

exports.applyLeave = async (req, res) => {
  try {
    const { employeeId, startDate, endDate, reason } = req.body;
    const leave = await Leave.create({ employeeId, startDate, endDate, reason });
    res.status(201).json(leave);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.viewLeaveStatus = async (req, res) => {
  try {
    const leaves = await Leave.findAll({ where: { employeeId: req.params.employeeId } });
    res.status(200).json(leaves);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};