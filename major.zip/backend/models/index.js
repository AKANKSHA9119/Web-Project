const Sequelize = require('sequelize');
const sequelize = require('../config/database');
const Leave = require('./Leave');

const db = {};

db.Sequelize = Sequelize;
db.sequelize = sequelize;

db.Leave = Leave;

module.exports = db;