const express = require('express');
const router = express.Router();
const adminController = require('../controllers/adminController');

router.get('/leaves', adminController.getAllLeaves);
router.put('/leaves/:leaveId', adminController.updateLeaveStatus);

module.exports = router;