import { useState, useEffect } from 'react';
import axios from 'axios';

const AdminDashboard = () => {
  const [leaveRequests, setLeaveRequests] = useState([]);

  useEffect(() => {
    const fetchLeaveRequests = async () => {
      try {
        const response = await axios.get('/admin/leaves');
        setLeaveRequests(response.data);
      } catch (error) {
        console.error(error);
      }
    };
    fetchLeaveRequests();
  }, []);

  const handleStatusChange = async (leaveId, status) => {
    try {
      await axios.put(`/admin/leaves/${leaveId}`, { status });
      alert('Leave status updated successfully!');
    } catch (error) {
      console.error(error);
      alert('Failed to update leave status.');
    }
  };

  return (
    <div>
      <h1>Admin Dashboard</h1>
      <ul>
        {leaveRequests.map((leave) => (
          <li key={leave.id}>
            <p>Employee ID: {leave.employeeId}</p>
            <p>Start Date: {leave.startDate}</p>
            <p>End Date: {leave.endDate}</p>
            <p>Reason: {leave.reason}</p>
            <p>Status: {leave.status}</p>
            <button onClick={() => handleStatusChange(leave.id, 'Approved')}>Approve</button>
            <button onClick={() => handleStatusChange(leave.id, 'Rejected')}>Reject</button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default AdminDashboard;