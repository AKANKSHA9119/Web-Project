import { useState } from 'react';
import axios from 'axios';

const LeaveApplication = () => {
  const [formData, setFormData] = useState({
    employeeId: '',
    startDate: '',
    endDate: '',
    reason: ''
  });

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post('/employee/apply', formData);
      alert('Leave applied successfully!');
    } catch (error) {
      console.error(error);
      alert('Failed to apply for leave.');
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <input type="text" name="employeeId" placeholder="Employee ID" onChange={handleChange} required />
      <input type="date" name="startDate" onChange={handleChange} required />
      <input type="date" name="endDate" onChange={handleChange} required />
      <textarea name="reason" placeholder="Reason for leave" onChange={handleChange} required></textarea>
      <button type="submit">Apply for Leave</button>
    </form>
  );
};

export default LeaveApplication;