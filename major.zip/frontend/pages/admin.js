import Head from 'next/head';
import AdminDashboard from '../components/AdminDashboard';

export default function Admin() {
  return (
    <div>
      <Head>
        <title>Admin Dashboard</title>
      </Head>
      <AdminDashboard />
    </div>
  );
}