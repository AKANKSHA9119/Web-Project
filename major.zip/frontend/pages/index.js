import Head from 'next/head';
import LeaveApplication from '../components/LeaveApplication';

export default function Home() {
  return (
    <div>
      <Head>
        <title>Employee Leave Management</title>
      </Head>
      <LeaveApplication />
    </div>
  );
}